
package dao;

import java.io.Serializable;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author asoka
 */
public class GeneralDao<X> {
    private Class<X> type;
    public GeneralDao(Class<X> type) {
        this.type = type;
    }
   
    public void create(X obj){
        Session ss = NewHibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.save(obj);
        ss.getTransaction().commit();
        ss.close();
    }
    
    public void update(X obj){
        Session ss = NewHibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.update(obj);
        
        ss.getTransaction().commit();
        ss.close();
    }
    
    public void delete(X obj){
        Session ss = NewHibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.delete(obj);
        ss.getTransaction().commit();
        ss.close();
    }
    
    public X findById(Serializable id){
        Session ss = NewHibernateUtil.getSessionFactory().openSession();
        X obj = (X)ss.get(type, id);
        ss.close();
        return obj;
    }
    
    public List<X> findAll(){
        Session ss = NewHibernateUtil.getSessionFactory().openSession();
        Query qry = ss.createQuery("from "+type.getName());
        List<X> list = qry.list();
        ss.close();
        return list;
    }

    public Object findByUsername(String username) {
        Session ss = NewHibernateUtil.getSessionFactory().openSession();
        X obj = (X)ss.get(type, username);
        ss.close();
        return obj;
    }
    
}
