/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import dao.NewHibernateUtil;
import java.time.LocalDate;
import org.hibernate.Session;

/**
 *
 * @author asoka
 */
public class Test {
 
    
    
    public static void main(String[] args) {
        
        
         Session ss = NewHibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
//        ss.save(obj);
        ss.getTransaction().commit();
        ss.close();

    }
}
