/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.GeneralDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.User;

/**
 *
 * @author asoka
 */
@WebServlet(name = "UserController", urlPatterns = {"/register"})
public class UserController extends HttpServlet {


    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username=req.getParameter("username");
        String fisrtName=req.getParameter("firstName");
        String lastName=req.getParameter("lastName");
        String gender=req.getParameter("gender");
        Integer age=Integer.parseInt(req.getParameter("age"));
        
        LocalDate regDate=LocalDate.parse(req.getParameter("regDate"));
        
        User user=new User(username, fisrtName, lastName, gender,regDate, "Active");
        GeneralDao dao=new GeneralDao(User.class);
        User user2=(User)dao.findByUsername(user.getUsername());
        if(user2!=null){
            
            req.getSession().setAttribute("error", "User already exists");
            resp.sendRedirect("userRegistrationForm.jsp");
            return;
            
        }
        dao.create(user);
         req.getSession().setAttribute("success", "User"+ user.getLastName()+""+ user.getFirstName()+"successfully created");
        resp.sendRedirect("userList.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String status=req.getParameter("status");
        String username=req.getParameter("username");
        GeneralDao dao=new GeneralDao(User.class);
        User user=(User)dao.findByUsername(username);
        user.setStatus(status);
        dao.update(user);
        resp.sendRedirect("userList.jsp");
        
        
        
    }
    
    
    
}
