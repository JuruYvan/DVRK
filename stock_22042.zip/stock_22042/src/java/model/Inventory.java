/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author SG
 */
@Entity
public class Inventory {
  @Id
  private int code;
  private String name;
  private int unit_price;
  private int quantity;
  private LocalDate recording_date;

    public Inventory() {
    }

    public Inventory(int code, String name, int unit_price, int quantity, LocalDate recording_date) {
        this.code = code;
        this.name = name;
        this.unit_price = unit_price;
        this.quantity = quantity;
        this.recording_date = recording_date;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(int unit_price) {
        this.unit_price = unit_price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public LocalDate getRecording_date() {
        return recording_date;
    }

    public void setRecording_date(LocalDate recording_date) {
        this.recording_date = recording_date;
    }
  
  
}
