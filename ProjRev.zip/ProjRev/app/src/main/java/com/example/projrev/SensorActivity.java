package com.example.projrev;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class SensorActivity extends AppCompatActivity {

    TextView text;
    Button btn;
    SensorManager sensorManager;
    List<Sensor> deviceSensors;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);

        btn = (Button)findViewById(R.id.back_sens);
        text = (TextView)findViewById(R.id.textViewSensors);
        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        deviceSensors = sensorManager.getSensorList(Sensor.TYPE_ALL);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });

        printSensors();
    }

    private void printSensors(){
        for (Sensor sensor: deviceSensors)
        {
            text.setText(text.getText()+"\n"+ sensor.getName());
        }
    }
}