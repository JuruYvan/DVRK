package com.example.projrev;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    CardView sens, i18n, geo, api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sens = (CardView)findViewById(R.id.sensors);
        i18n = (CardView)findViewById(R.id.internalization);
        geo = (CardView)findViewById(R.id.geolocation);
        api = (CardView)findViewById(R.id.google_api);

        sens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intSens = new Intent(getApplicationContext(), SensorActivity.class);
                startActivity(intSens);
            }
        });

        i18n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intInter = new Intent(getApplicationContext(), InternalizationActivity.class);
                startActivity(intInter);
            }
        });

        geo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intGeo = new Intent(getApplicationContext(), GeoLocationActivity.class);
                startActivity(intGeo);
            }
        });

        api.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intAPI = new Intent(getApplicationContext(), GoogleApiActivity.class);
                startActivity(intAPI);
            }
        });
    }
}