/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.reg.model;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import com.reg.dao.GeneralDao;
import com.reg.domain.Course;
import com.reg.domain.Student;

/**
 *
 * @author diddy
 */
@ManagedBean(name = "CourseReg")
@SessionScoped
public class CourseRegistrationModel {

    private Student student = new Student();
    private List<Course> courses;
    private List<Course> registeredCourse = new ArrayList<>();

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public List<Course> getRegisteredCourse() {
        return registeredCourse;
    }

    public void setRegisteredCourse(List<Course> registeredCourse) {
        this.registeredCourse = registeredCourse;
    }

    public void addCourse(Course course) {
        registeredCourse.add(course);
        student.setCourses(registeredCourse);
    }

    public void removeCourse(Course course) {
        registeredCourse.remove(course);
    }

    public List<Course> getProductList() {
        return registeredCourse;
    }

    public Integer getCount() {
        return registeredCourse.size();
    }

    public Integer totalCredits() {
        int credits = 0;
        for (Course c : registeredCourse) {
            credits += c.getCredits();
        }
        return credits;
    }

    public Integer getTotal() {
        int total = 0;
        for (Course p : registeredCourse) {
            total += p.getFees();
        }
        
        return total;
    }
    
    public boolean checkCourse(Course course){
       return registeredCourse.contains(course);
    }

    public String next() {
        try {
            FacesContext context = FacesContext.getCurrentInstance();
            HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
            session.setAttribute("student", student);
            return "courseList";

        } catch (Exception ex) {
            ex.printStackTrace();
            return "index";
        }
    }
    public String save() {
        try {
            GeneralDao<Student> dao = new GeneralDao<>(Student.class);
            dao.create(student);
            FacesMessage msg = new FacesMessage("student saved successfully");
            FacesContext context = FacesContext.getCurrentInstance();
            return "register";
        } catch (Exception ex) {
            FacesMessage msg = new FacesMessage("student not saved");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return "index";
        }
    }
    public List<Course> getAll() {
        try {
            GeneralDao<Course> dao = new GeneralDao<>(Course.class);
            courses = dao.findAll();
            return courses;
        } catch (Exception ex) {
            return courses;
        }
    }

}
