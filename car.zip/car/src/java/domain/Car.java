/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author User
 */
@Entity
@Table(name="Car")
public class Car {
  @Id  
  private String plateNo;
  private String Model;
  private String institution;
  private int manufacturingyear;
  private Date entranceDate;
  private long purchaseCost;

    public Car() {
    }

    public Car(String plateNo, String Model, String institution, int manufacturingyear, Date entranceDate, long purchaseCost) {
        this.plateNo = plateNo;
        this.Model = Model;
        this.institution = institution;
        this.manufacturingyear = manufacturingyear;
        this.entranceDate = entranceDate;
        this.purchaseCost = purchaseCost;
    }

    public String getPlateNo() {
        return plateNo;
    }

    public void setPlateNo(String plateNo) {
        this.plateNo = plateNo;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public int getManufacturingyear() {
        return manufacturingyear;
    }

    public void setManufacturingyear(int manufacturingyear) {
        this.manufacturingyear = manufacturingyear;
    }

    public Date getEntranceDate() {
        return entranceDate;
    }

    public void setEntranceDate(Date entranceDate) {
        this.entranceDate = entranceDate;
    }

    public long getPurchaseCost() {
        return purchaseCost;
    }

    public void setPurchaseCost(long purchaseCost) {
        this.purchaseCost = purchaseCost;
    }
  
}
