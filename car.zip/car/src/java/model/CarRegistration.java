/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import dao.GeneralDao;
import domain.Car;
import java.util.Date;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

/**
 *
 * @author User
 */
@ManagedBean(name="carCrud")
public class CarRegistration  {
    
    private Car car = new Car();
    private GeneralDao <Car> dao = new GeneralDao<>(Car.class);
    private List<Car> cars;
    private String action = "Create";
    
    
    
    
    
    public String regcar(){
         FacesContext faces =  FacesContext.getCurrentInstance();
        String massage = Validate();
        
        if(massage.equals("validated")){
           
            try {
            if(action.equals("Create")){
                dao.create(car);
            }
            else if(action.equals("Update")){
                dao.update(car);
            }
            return "registeredCarList";
        } catch (Exception e) {
             return "carRegistrationForm";
        }
            
        }else{
            faces.addMessage("samantha", new FacesMessage(massage) );
        }
        return "carregistrationform.xhtml";
    }
    
    
    
    
   
  
    
    
    
    public String update(Car cars){
        this.car = cars;
        this.action = "Update";
        return "carregistrationform";
        
}
    
    
     public String Delete(Car cars){
       dao.delete(cars);
      return "registeredCarList";
   }
     
     
     

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
    
public Car getCar(){
    return car;
}
public List<Car> listAll(){
    return dao.listAll();
}

  
  public String Validate(){
  if(!car.getPlateNo().matches("GP[0-9]{3}[A-Z]")&&!car.getPlateNo().matches("GR[0-9]{3}[A-Z]")){
      return "plate should be GR001A or GP001E";
  }
    if(car.getManufacturingyear() < 2000){
       return "this year is wrong";
   }
   else if(car.getPurchaseCost() > 100000000 || car.getPurchaseCost() < 1000000){
            return "The cost of a car should not be less than 1,000,000 FRW or greater than 100,0000,000 FRW";
   }
   else if(car.getPlateNo().length() > 4){
          return "Plate number Should be not greater than 4";
      }
  
  return "validated";
}


}
