/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

/**
 *
 * @author hp
 */
public class Dao<X> {
     Class<X> type;
     public Transaction tx=null;
     public Session ss = null;
    public Dao(Class<X> type) {
        this.type = type;
    }
    public void create(X obj) {
        ss = HibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.save(obj);
        ss.getTransaction().commit();
        ss.close();
    }
    public void update(X obj) {
        ss = HibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.update(obj);
        ss.getTransaction().commit();
        ss.close();
    }
    public void delete(X obj) { 
        ss = HibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.delete(obj);
        ss.getTransaction().commit();
        ss.close();
    }
    public List<X> findAll() {
        ss = HibernateUtil.getSessionFactory().openSession();
        Query qry = ss.createQuery("from " + type.getName());
        List<X> list = qry.list();
        ss.close();
        return list;
    }
    public X findById(String id) {
        ss = HibernateUtil.getSessionFactory().openSession();
        X obj = (X) ss.get(type, id);
        ss.close();
        return obj;
    }
    public X finds(String name){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where name=:name");
        query.setParameter("name",name);
        X x = (X) query.uniqueResult();
        ss.close();
        return x;
    }
    public List<X> findss(String name){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where name LIKE :name");
        query.setParameter("name",'%'+name+'%');
        List<X>  x = query.list();
        ss.close();
        return x;
    }
    public List<X> available(){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where availabe=:avialable");
        query.setParameter("avialable", true);
        List<X> x = query.list();
        ss.close();
        return x;
    }
    public X findByNames(String[] names){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where firstName=:firstname and lastName=:lastname");
        query.setParameter("firstname", names[0]);
        query.setParameter("lastname", names[1]);
        X x = (X) query.uniqueResult();
        ss.close();
        return x;
    }
    
    public List<X> findByName(String name){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where (firstName LIKE :name and lastName LIKE :name) or (firstName LIKE :name or lastName LIKE :name)");
        query.setParameter("name",'%'+name+'%');
        List<X> x = query.list();
        ss.close();
        return x;
    }
    public List<X> findByClientId(String id){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where clientid=:id");
        query.setParameter("id", id);
        List<X> x = query.list();
        ss.close();
        return x;
    }
    // this function is still in develpement do not use it before it is done 
    public List<X> findByCategory(String category){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where category_code=:category");
        query.setParameter("category", category);
        List<X> x = query.list();
        ss.close();
        return x;
    }
    
    
    public X findByTitle(String title){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where title LIKE:title");
        query.setParameter("title",'%'+title+'%');
        X x = (X) query.uniqueResult();
        ss.close();
        return x;
    }
    
    public List<X> findByTitles(String title){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where title LIKE:title");
        query.setParameter("title",'%'+title+'%');
        List<X> x = query.list();
        ss.close();
        return x;
    }
    
    public List<X> findByDate(Date date){
        ss = HibernateUtil.getSessionFactory().openSession();
        Query query= ss.createQuery("from "+ type.getName()+" where transactionDate=:date or returnDate=:date");
        query.setParameter("date",date);
        List<X> x = query.list();
        ss.close();
        return x;
    }
    
     public void batch(List<X> list) throws InterruptedException{              
        try{           
            ss = HibernateUtil.getSessionFactory().openSession();
            int batchSize=25;
            int count=0;
            
            tx = ss.beginTransaction();
            for(X data: list){
                count++;                
                ss.save(data);               
                //int currentValue=Integer.parseInt(String.valueOf(count*100/(employees.size()))); 
                if(count%batchSize == 0){
                    tx.commit();                  
                    tx=ss.beginTransaction();                   
                }
            }
            if(tx!=null){
                tx.commit();
            }

            JOptionPane.showMessageDialog(null, count + " employees have been loaded in the database successfully!", "Saving mass  in the database", JOptionPane.INFORMATION_MESSAGE);
            Thread.sleep(1000); 
        }catch(HibernateException e){
            if(tx!=null){
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e);
        }finally{
            ss.close();
        }
    }
}
