/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author Seka
 */
@Entity
public class Car {
    @Id
    private String platno;
    private LocalDate ManufactureDate;
    private int cost;
    private String institution;

    public Car() {
    }

    public Car(String platno) {
        this.platno = platno;
    }

    
    public Car(String platno, LocalDate ManufactureDate, int cost, String institution) {
        this.platno = platno;
        this.ManufactureDate = ManufactureDate;
        this.cost = cost;
        this.institution = institution;
    }

    public void setPlatno(String platno) {
        this.platno = platno;
    }

    public void setManufactureDate(LocalDate ManufactureDate) {
        this.ManufactureDate = ManufactureDate;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public String getPlatno() {
        return platno;
    }

    public LocalDate getManufactureDate() {
        return ManufactureDate;
    }

    public int getCost() {
        return cost;
    }

    public String getInstitution() {
        return institution;
    }
    
}
