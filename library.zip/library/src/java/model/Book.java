/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author SG
 */
@Entity
public class Book {
    @Id
    private String ISBN;
    private String description;
    private String category;
    private int purchasingPrice;
    private int sellingPrice;
    private LocalDate recording;

    public Book() {
    }

    public Book(String ISBN, String description, String category, int purchasingPrice, int sellingPrice, LocalDate recording) {
        this.ISBN = ISBN;
        this.description = description;
        this.category = category;
        this.purchasingPrice = purchasingPrice;
        this.sellingPrice = sellingPrice;
        this.recording = recording;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getPurchasingPrice() {
        return purchasingPrice;
    }

    public void setPurchasingPrice(int purchasingPrice) {
        this.purchasingPrice = purchasingPrice;
    }

    public int getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(int sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public LocalDate getRecording() {
        return recording;
    }

    public void setRecording(LocalDate recording) {
        this.recording = recording;
    }
    
    
    
}
