/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author divine
 */
@Entity
@Table(name="atmcards")
public class Atmcard {
    @Id
    private String cardno;
    private String cardtype;
    private String customername;
    private Date issuedate;
    private Date validuntil;

    public Atmcard() {
    }

    public Atmcard(String cardno) {
        this.cardno = cardno;
    }
    

    public Atmcard(String cardno, String cardtype, String customername, Date issuedate, Date validuntil) {
        this.cardno = cardno;
        this.cardtype = cardtype;
        this.customername = customername;
        this.issuedate = issuedate;
        this.validuntil = validuntil;
    }

    
    
    public String getCardno() {
        return cardno;
    }
    

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public String getCardtype() {
        return cardtype;
    }

    public void setCardtype(String cardtype) {
        this.cardtype = cardtype;
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public Date getIssuedate() {
        return issuedate;
    }

    public void setIssuedate(Date issuedate) {
        this.issuedate = issuedate;
    }

    public Date getValiduntil() {
        return validuntil;
    }

    public void setValiduntil(Date validuntil) {
        this.validuntil = validuntil;
    }
    
    
    
    
    
}
