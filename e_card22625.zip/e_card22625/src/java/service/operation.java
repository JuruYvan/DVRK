/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.GeneralDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Atmcard;

/**
 *
 * @author divine
 */
@WebServlet(name = "operation", urlPatterns = {"/operation"})
public class operation extends HttpServlet {
    private Map<String,String> errorMsg;
    GeneralDao dao=new GeneralDao(Atmcard.class);
    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet operation</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet operation at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String path = request.getPathInfo();
       if("/delete".equals(path)){
           String cardn = request.getParameter("cardno");
           Atmcard atmcard = new Atmcard(cardn);
           dao.delete(atmcard);
           response.sendRedirect("/e_card22625/listcard.jsp");
       }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path=request.getPathInfo();
        Atmcard atmcard=getFormData(request);
        if(validateCard(atmcard)){
            if(path==null){
                dao.create(atmcard);
                response.sendRedirect("/e_card22625/listcard.jsp");
            }else if("/update".equals(path)){
                dao.update(atmcard);
                response.sendRedirect("/e_card22625/listcard.jsp");
            }
            
        }else{
            request.getSession().setAttribute("insert",errorMsg);
            response.sendRedirect("/e_card22625/cardRegistrationForm");
        }
        
    }
    public Atmcard getFormData(HttpServletRequest request){
        String no=request.getParameter("cardno");
        String type=request.getParameter("type");
        String names=request.getParameter("customer");
        Date d = Date.valueOf(LocalDate.now());
        Date val=Date.valueOf(request.getParameter("validdate"));
        
        Atmcard atmcard=new Atmcard(no, type, names, d, val);
        return atmcard;
    }
    public boolean validateCard(Atmcard atmcard){
        
        errorMsg=new HashMap<>();
        if(!atmcard.getCardno().matches("[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}")){
            errorMsg.put("atmCardno", "must be 16 digids separated by 4 digit");
        }
       if(errorMsg.isEmpty()){
           return true;
       }
       return false;
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
